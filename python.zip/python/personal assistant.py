

import argparse
import os
import sys
import json
import sqlite3
import hashlib
from datetime import datetime
from dateutil import parser as dateparser
import requests
from bs4 import BeautifulSoup
import pandas as pd
from typing import List, Dict, Optional, Tuple


def ensure_db(conn: sqlite3.Connection):
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY,
            uid TEXT UNIQUE,
            title TEXT,
            url TEXT,
            source TEXT,
            published_at TEXT,
            summary TEXT,
            fetched_at TEXT
        )
    ''')
    conn.commit()


def make_uid(title: str, url: str) -> str:
    # deterministic UID for deduplication (title + url hash)
    h = hashlib.sha256()
    h.update((title or "").encode('utf-8', errors='ignore'))
    h.update((url or "").encode('utf-8', errors='ignore'))
    return h.hexdigest()


def parse_iso(date_str: Optional[str]) -> Optional[str]:
    if not date_str:
        return None
    try:
        dt = dateparser.parse(date_str)
        return dt.isoformat()
    except Exception:
        return None


NEWSAPI_URL = "https://newsapi.org/v2/everything"


def fetch_newsapi(api_key: str, q: Optional[str] = None, sources: Optional[List[str]] = None,
                  from_date: Optional[str] = None, to_date: Optional[str] = None, page_size=100) -> List[Dict]:
    if not api_key:
        raise ValueError("NEWSAPI_KEY missing")
    params = {
        'pageSize': page_size,
        'q': q,
        'sources': ','.join(sources) if sources else None,
        'from': from_date,
        'to': to_date,
        'language': 'en',
        'sortBy': 'publishedAt'
    }
    # remove None
    params = {k: v for k, v in params.items() if v is not None}
    headers = {'Authorization': api_key}
    print(f"[newsapi] fetching with params: {params}")
    r = requests.get(NEWSAPI_URL, params=params, headers=headers, timeout=15)
    r.raise_for_status()
    payload = r.json()
    articles = []
    for a in payload.get('articles', []):
        articles.append({
            'title': a.get('title'),
            'url': a.get('url'),
            'source': (a.get('source') or {}).get('name'),
            'published_at': parse_iso(a.get('publishedAt')),
            'summary': a.get('description') or a.get('content')
        })
    return articles



def fetch_rss_feed(feed_url: str) -> List[Dict]:
    """Simple RSS fetcher using requests + BeautifulSoup. Not a full RSS parser but works for many feeds."""
    print(f"[rss] fetching {feed_url}")
    r = requests.get(feed_url, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.content, 'xml')
    items = []
    for item in soup.find_all('item'):
        title = item.find('title') and item.find('title').text
        link = item.find('link') and item.find('link').text
        pub = item.find('pubDate') and item.find('pubDate').text
        desc = item.find('description') and item.find('description').text
        items.append({
            'title': title,
            'url': link,
            'source': feed_url,
            'published_at': parse_iso(pub),
            'summary': desc
        })
    return items

# ----------------------------- Site Scrapers -----------------------------

def scrape_bbc_latest() -> List[Dict]:
    """Very simple BBC headlines scraper (may break if BBC changes markup)."""
    url = 'https://www.bbc.com/news'
    print(f"[scrape] fetching BBC: {url}")
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    items = []
    for h in soup.select('a.gs-c-promo-heading')[:30]:
        title = h.get_text(strip=True)
        link = h.get('href')
        if link and link.startswith('/'):
            link = 'https://www.bbc.com' + link
        items.append({'title': title, 'url': link, 'source': 'BBC', 'published_at': None, 'summary': None})
    return items


def scrape_reuters_latest() -> List[Dict]:
    url = 'https://www.reuters.com'
    print(f"[scrape] fetching Reuters: {url}")
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    items = []
    for tag in soup.select('article a[href]')[:40]:
        title = tag.get_text(strip=True)
        link = tag.get('href')
        if not title:
            continue
        if link and link.startswith('/'):
            link = 'https://www.reuters.com' + link
        items.append({'title': title, 'url': link, 'source': 'Reuters', 'published_at': None, 'summary': None})
    return items

# ----------------------------- Storage -----------------------------------


def store_articles(conn: sqlite3.Connection, articles: List[Dict]) -> Tuple[int,int]:
    """Insert articles into SQLite with deduplication by uid (unique). Returns (inserted, skipped)"""
    c = conn.cursor()
    inserted = 0
    skipped = 0
    for a in articles:
        uid = make_uid(a.get('title') or '', a.get('url') or '')
        fetched_at = datetime.utcnow().isoformat()
        try:
            c.execute('''INSERT INTO articles (uid, title, url, source, published_at, summary, fetched_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?)''',
                      (uid, a.get('title'), a.get('url'), a.get('source'), a.get('published_at'), a.get('summary'), fetched_at))
            inserted += 1
        except sqlite3.IntegrityError:
            skipped += 1
    conn.commit()
    return inserted, skipped


def export_to_json(articles: List[Dict], out_file: str):
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(articles, f, ensure_ascii=False, indent=2)
    print(f"Exported {len(articles)} articles to {out_file}")


def export_table_to_file(conn: sqlite3.Connection, query: str, out_file: str, fmt: str):
    df = pd.read_sql_query(query, conn)
    if fmt == 'csv':
        df.to_csv(out_file, index=False)
    elif fmt == 'excel' or fmt == 'xlsx':
        df.to_excel(out_file, index=False)
    elif fmt == 'json':
        df.to_json(out_file, orient='records', force_ascii=False, indent=2)
    else:
        raise ValueError('Unsupported export format')
    print(f"Exported {len(df)} rows to {out_file}")

# ----------------------------- Querying ---------------------------------

def build_query(keyword: Optional[str], source: Optional[str], from_date: Optional[str], to_date: Optional[str]) -> Tuple[str, List]:
    clauses = []
    params = []
    if keyword:
        clauses.append('(title LIKE ? OR summary LIKE ?)')
        like = f'%{keyword}%'
        params.extend([like, like])
    if source:
        clauses.append('source = ?')
        params.append(source)
    if from_date:
        clauses.append('published_at >= ?')
        params.append(parse_iso(from_date) or from_date)
    if to_date:
        clauses.append('published_at <= ?')
        params.append(parse_iso(to_date) or to_date)
    where = (' WHERE ' + ' AND '.join(clauses)) if clauses else ''
    sql = 'SELECT * FROM articles' + where + ' ORDER BY published_at DESC NULLS LAST'
    return sql, params

# ----------------------------- CLI Actions -------------------------------

def action_fetch(args):
    # Prepare DB
    db_path = args.db or 'news.db'
    conn = sqlite3.connect(db_path)
    ensure_db(conn)

    all_articles = []

    # NewsAPI
    if args.use_newsapi:
        api_key = os.getenv('NEWSAPI_KEY')
        if not api_key:
            print('ERROR: NEWSAPI_KEY not set in environment. Skipping NewsAPI fetch.')
        else:
            try:
                na = fetch_newsapi(api_key, q=args.q, sources=(args.sources.split(',') if args.sources else None),
                                   from_date=args.from_date, to_date=args.to_date)
                all_articles.extend(na)
            except Exception as e:
                print('NewsAPI fetch error:', e)

    # RSS feeds
    if args.use_rss:
        feeds = [
            'http://feeds.bbci.co.uk/news/rss.xml',
            'http://rss.cnn.com/rss/edition.rss'
        ]
        for f in feeds:
            try:
                all_articles.extend(fetch_rss_feed(f))
            except Exception as e:
                print('RSS fetch error for', f, e)

    # Built-in scrapers
    if args.use_scrapers:
        try:
            all_articles.extend(scrape_bbc_latest())
        except Exception as e:
            print('BBC scrape error', e)
        try:
            all_articles.extend(scrape_reuters_latest())
        except Exception as e:
            print('Reuters scrape error', e)

    # Basic deduplication in-memory by uid
    unique = {}
    for a in all_articles:
        uid = make_uid(a.get('title') or '', a.get('url') or '')
        if uid not in unique:
            unique[uid] = a
    deduped = list(unique.values())
    print(f"Fetched {len(all_articles)} items, {len(deduped)} after in-memory dedupe.")

    # Optionally store in DB
    if args.db:
        inserted, skipped = store_articles(conn, deduped)
        print(f"DB: inserted {inserted}, skipped {skipped} (duplicates)")

    # Optionally export to JSON/CSV/Excel immediate output
    if args.export and args.out_file:
        fmt = args.export.lower()
        if fmt == 'json':
            export_to_json(deduped, args.out_file)
        else:
            # Use pandas to create file
            df = pd.DataFrame(deduped)
            if fmt == 'csv':
                df.to_csv(args.out_file, index=False)
            elif fmt in ('excel', 'xlsx'):
                df.to_excel(args.out_file, index=False)
            else:
                print('Unsupported immediate export format:', fmt)
            print(f"Exported {len(df)} rows to {args.out_file}")

    conn.close()


def action_query(args):
    db_path = args.db or 'news.db'
    if not os.path.exists(db_path):
        print('DB does not exist at', db_path)
        return
    conn = sqlite3.connect(db_path)

    sql, params = build_query(args.keyword, args.source, args.from_date, args.to_date)
    print('Executing SQL:', sql)
    df = pd.read_sql_query(sql, conn, params=params)
    print(df[['title', 'source', 'published_at']].to_string(index=False))

    if args.export and args.out_file:
        fmt = args.export.lower()
        export_table_to_file(conn, sql, args.out_file, fmt)

    conn.close()

# ----------------------------- CLI Setup --------------------------------

def build_argparse():
    p = argparse.ArgumentParser(description='News aggregator CLI')
    sub = p.add_subparsers(dest='cmd')

    # Fetch subcommand
    f = sub.add_parser('fetch', help='Fetch news from configured providers')
    f.add_argument('--use-newsapi', action='store_true', help='Use NewsAPI (requires NEWSAPI_KEY env var)')
    f.add_argument('--use-rss', action='store_true', help='Fetch pre-configured RSS feeds')
    f.add_argument('--use-scrapers', action='store_true', help='Use built-in scrapers (BBC, Reuters)')
    f.add_argument('--q', type=str, help='Query/keyword for NewsAPI')
    f.add_argument('--sources', type=str, help='Comma-separated source ids for NewsAPI')
    f.add_argument('--from-date', type=str, help='From date (YYYY-MM-DD or ISO)')
    f.add_argument('--to-date', type=str, help='To date (YYYY-MM-DD or ISO)')
    f.add_argument('--db', type=str, help='Path to SQLite DB to store results')
    f.add_argument('--export', type=str, choices=['json', 'csv', 'excel'], help='Export immediate results')
    f.add_argument('--out-file', type=str, help='Output file path for immediate export')

    # Query subcommand
    q = sub.add_parser('query', help='Query stored DB')
    q.add_argument('--keyword', type=str, help='Keyword to search in title/summary')
    q.add_argument('--source', type=str, help='Filter by source name')
    q.add_argument('--from-date', type=str, help='From date')
    q.add_argument('--to-date', type=str, help='To date')
    q.add_argument('--db', type=str, help='Path to SQLite DB')
    q.add_argument('--export', type=str, choices=['csv', 'excel', 'json'], help='Export query results')
    q.add_argument('--out-file', type=str, help='Output file for export')

    return p

# ----------------------------- Entrypoint -------------------------------

def main(argv=None):
    parser = build_argparse()
    args = parser.parse_args(argv)
    if not args.cmd:
        parser.print_help()
        return

    if args.cmd == 'fetch':
        action_fetch(args)
    elif args.cmd == 'query':
        action_query(args)
    else:
        print('Unknown command')


if __name__ == '__main__':
    main()
